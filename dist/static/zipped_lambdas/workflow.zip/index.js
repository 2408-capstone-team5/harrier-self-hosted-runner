// import { fromIni } from "@aws-sdk/credential-provider-ini"; // For loading credentials from ~/.aws/credentials
import {
  SSMClient,
  SendCommandCommand,
} from "@aws-sdk/client-ssm";
import {
  EC2Client,
  DescribeInstancesCommand,
  StartInstancesCommand,
  waitUntilInstanceRunning,
  StopInstancesCommand,
} from "@aws-sdk/client-ec2";

import {
  SecretsManagerClient,
  GetSecretValueCommand,
} from "@aws-sdk/client-secrets-manager";
import  { S3Client, ListBucketsCommand, GetBucketTaggingCommand } from '@aws-sdk/client-s3';

// type InstanceState =
//   | "stopped"
//   | "running"
//   | "pending"
//   | "stopping"
//   | "shutting-down"
//   | "terminated";

// const EVENT = {"action":"queued","workflow_job":{"id":32636610777,"run_id":11717251582,"workflow_name":"Build Docker NO CACHE self-hosted","head_branch":"main","run_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/actions/runs/11717251582","run_attempt":1,"node_id":"CR_kwDONETmjs8AAAAHmUso2Q","head_sha":"35c2dec6ebf127086cb9310b20a7424810b22198","url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/actions/jobs/32636610777","html_url":"https://github.com/2408-capstone-team5/test-node-js-app/actions/runs/11717251582/job/32636610777","status":"queued","conclusion":null,"created_at":"2024-11-07T05:35:34Z","started_at":"2024-11-07T05:35:34Z","completed_at":null,"name":"Push Docker image to Docker Hub","steps":[],"check_run_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/check-runs/32636610777","labels":["self-hosted"],"runner_id":null,"runner_name":null,"runner_group_id":null,"runner_group_name":null},"repository":{"id":876930702,"node_id":"R_kgDONETmjg","name":"test-node-js-app","full_name":"2408-capstone-team5/test-node-js-app","private":true,"owner":{"login":"2408-capstone-team5","id":185894799,"node_id":"O_kgDOCxSHjw","avatar_url":"https://avatars.githubusercontent.com/u/185894799?v=4","gravatar_id":"","url":"https://api.github.com/users/2408-capstone-team5","html_url":"https://github.com/2408-capstone-team5","followers_url":"https://api.github.com/users/2408-capstone-team5/followers","following_url":"https://api.github.com/users/2408-capstone-team5/following{/other_user}","gists_url":"https://api.github.com/users/2408-capstone-team5/gists{/gist_id}","starred_url":"https://api.github.com/users/2408-capstone-team5/starred{/owner}{/repo}","subscriptions_url":"https://api.github.com/users/2408-capstone-team5/subscriptions","organizations_url":"https://api.github.com/users/2408-capstone-team5/orgs","repos_url":"https://api.github.com/users/2408-capstone-team5/repos","events_url":"https://api.github.com/users/2408-capstone-team5/events{/privacy}","received_events_url":"https://api.github.com/users/2408-capstone-team5/received_events","type":"Organization","user_view_type":"public","site_admin":false},"html_url":"https://github.com/2408-capstone-team5/test-node-js-app","description":null,"fork":false,"url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app","forks_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/forks","keys_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/keys{/key_id}","collaborators_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/collaborators{/collaborator}","teams_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/teams","hooks_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/hooks","issue_events_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/issues/events{/number}","events_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/events","assignees_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/assignees{/user}","branches_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/branches{/branch}","tags_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/tags","blobs_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/git/blobs{/sha}","git_tags_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/git/tags{/sha}","git_refs_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/git/refs{/sha}","trees_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/git/trees{/sha}","statuses_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/statuses/{sha}","languages_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/languages","stargazers_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/stargazers","contributors_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/contributors","subscribers_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/subscribers","subscription_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/subscription","commits_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/commits{/sha}","git_commits_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/git/commits{/sha}","comments_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/comments{/number}","issue_comment_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/issues/comments{/number}","contents_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/contents/{+path}","compare_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/compare/{base}...{head}","merges_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/merges","archive_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/{archive_format}{/ref}","downloads_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/downloads","issues_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/issues{/number}","pulls_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/pulls{/number}","milestones_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/milestones{/number}","notifications_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/notifications{?since,all,participating}","labels_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/labels{/name}","releases_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/releases{/id}","deployments_url":"https://api.github.com/repos/2408-capstone-team5/test-node-js-app/deployments","created_at":"2024-10-22T19:42:20Z","updated_at":"2024-11-06T16:50:07Z","pushed_at":"2024-11-06T16:50:03Z","git_url":"git://github.com/2408-capstone-team5/test-node-js-app.git","ssh_url":"git@github.com:2408-capstone-team5/test-node-js-app.git","clone_url":"https://github.com/2408-capstone-team5/test-node-js-app.git","svn_url":"https://github.com/2408-capstone-team5/test-node-js-app","homepage":null,"size":774,"stargazers_count":0,"watchers_count":0,"language":"JavaScript","has_issues":true,"has_projects":true,"has_downloads":true,"has_wiki":false,"has_pages":false,"has_discussions":false,"forks_count":0,"mirror_url":null,"archived":false,"disabled":false,"open_issues_count":0,"license":null,"allow_forking":false,"is_template":false,"web_commit_signoff_required":false,"topics":[],"visibility":"private","forks":0,"open_issues":0,"watchers":0,"default_branch":"main","custom_properties":{}},"organization":{"login":"2408-capstone-team5","id":185894799,"node_id":"O_kgDOCxSHjw","url":"https://api.github.com/orgs/2408-capstone-team5","repos_url":"https://api.github.com/orgs/2408-capstone-team5/repos","events_url":"https://api.github.com/orgs/2408-capstone-team5/events","hooks_url":"https://api.github.com/orgs/2408-capstone-team5/hooks","issues_url":"https://api.github.com/orgs/2408-capstone-team5/issues","members_url":"https://api.github.com/orgs/2408-capstone-team5/members{/member}","public_members_url":"https://api.github.com/orgs/2408-capstone-team5/public_members{/member}","avatar_url":"https://avatars.githubusercontent.com/u/185894799?v=4","description":null},"sender":{"login":"shaneziegler","id":56492231,"node_id":"MDQ6VXNlcjU2NDkyMjMx","avatar_url":"https://avatars.githubusercontent.com/u/56492231?v=4","gravatar_id":"","url":"https://api.github.com/users/shaneziegler","html_url":"https://github.com/shaneziegler","followers_url":"https://api.github.com/users/shaneziegler/followers","following_url":"https://api.github.com/users/shaneziegler/following{/other_user}","gists_url":"https://api.github.com/users/shaneziegler/gists{/gist_id}","starred_url":"https://api.github.com/users/shaneziegler/starred{/owner}{/repo}","subscriptions_url":"https://api.github.com/users/shaneziegler/subscriptions","organizations_url":"https://api.github.com/users/shaneziegler/orgs","repos_url":"https://api.github.com/users/shaneziegler/repos","events_url":"https://api.github.com/users/shaneziegler/events{/privacy}","received_events_url":"https://api.github.com/users/shaneziegler/received_events","type":"User","user_view_type":"public","site_admin":false}}

// const getRegionFromArn = (context) => {
//   const arn = context.invokedFunctionArn;
//   const region = arn.split(":")[3];
//   console.log("Lambda ARN region:", region);
//   return region;
// };

const HARRIER_TAG_KEY = "Agent";
const HARRIER_TAG_VALUE = "Harrier-Runner";
const REGION = process.env.AWS_REGION;
// const REGION = "us-east-1"; // Change to your desired region

// User needs to use the exact below secret name
const secretName = "github/token/harrier";

// Initialize the Secrets Manager client
const secretClient = new SecretsManagerClient({
  region: REGION,
});

// Initialize the SSM client
const ssmClient = new SSMClient({
  region: REGION,
  // credentials: fromIni({ profile: "default" }), // Load credentials from the default profile
});

// Initialize the EC2 client
const ec2Client = new EC2Client({
  region: REGION,
  // credentials: fromIni({ profile: "default" }), // Load credentials from the default profile
});

// Initialize the S3 client
const s3Client = new S3Client({
  region: REGION,
  // credentials: fromIni({ profile: "default" }), // Load credentials from the default profile
});


async function findS3Bucket() {
  try {
    const bucketList = await s3Client.send(new ListBucketsCommand({}));
    // console.log('*** BUCKETLIST ***');
    // console.log(bucketList);
    // console.log('****************');
    for (const bucket of bucketList.Buckets) {
        const bucketName = bucket.Name;
        // console.log(`BucketName: ${bucketName}`);

        try {
          const taggingData = await s3Client.send(new GetBucketTaggingCommand({ Bucket: bucketName }));
          // console.log(`taggingData: ${taggingData}`);
          
          const tags = taggingData.TagSet;
          // console.log(`tags: ${tags}`);
          const tag = tags.find(tag => tag.Key === HARRIER_TAG_KEY && tag.Value === HARRIER_TAG_VALUE);

          if (tag) {
              console.log(`✅ Bucket with tag "${tag.Key}:${tag.Value}" found: ${bucketName}`);
              return bucketName; // Return the matching bucket name
          }
        } catch (error) {
          console.log(`No tags found on bucket: ${bucketName}`);
        }
    }
    console.log(`❌ No bucket found with tag "${HARRIER_TAG_KEY}:${HARRIER_TAG_VALUE}"`);
  } catch (error) {
      console.error(`❌ Error fetching bucket with tag ${HARRIER_TAG_KEY}:${HARRIER_TAG_VALUE}`, error);
  }
}


async function findInstance(state) {
  try {
    const params = {
      Filters: [
        { Name: "instance-state-name", Values: [state] },
        {
          Name: `tag:${HARRIER_TAG_KEY}`,
          Values: [HARRIER_TAG_VALUE],
        },
      ],
    };

    const command = new DescribeInstancesCommand(params);
    const data = await ec2Client.send(command);

    let instanceId;
    if (data.Reservations?.length) {
      instanceId = data.Reservations[0].Instances[0].InstanceId;
      console.log("✅ Found instance:", instanceId);
      return instanceId;
    } else {
      return undefined;
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error("❌ Error finding instance:", error.message);
    } else {
      console.error("❌ Unexpected error:", error);
    }
    return undefined;
  }
}

async function startInstance(instanceId) {
  try {
    console.log(`Trying to start instanceId: ${instanceId}`);
    const params = {
      InstanceIds: [instanceId],
    };
    const command = new StartInstancesCommand(params);
    const response = await ec2Client.send(command);
    console.log("✅ Instance start command sent:", response.StartingInstances);
  } catch (error) {
    console.error("❌ Error starting instances:", error);
  }
}

async function stopInstance(instanceId) {
  try {
    const command = new StopInstancesCommand({ InstanceIds: [instanceId] });
    const response = await ec2Client.send(command);
    console.log("✅ Stopping instance:", response.StoppingInstances);
  } catch (error) {
    console.error("❌ Error stopping instance:", error);
  }
}

const MAX_WAITER_TIME_IN_SECONDS = 60 * 8;

async function waitForInstanceRunning(instanceId) {
  try {
    console.log(`Polling InstanceId ${instanceId} until RUNNING.`);
    const startTime = new Date();
    await waitUntilInstanceRunning(
      {
        client: ec2Client,
        maxWaitTime: MAX_WAITER_TIME_IN_SECONDS,
      },
      { InstanceIds: [instanceId] }
    );
    const endTime = new Date();
    console.log(
      "✅ RUNNING Succeeded after time: ",
      (endTime.getTime() - startTime.getTime()) / 1000
    );
  } catch (error) {
    console.error("❌ Error waiting for instance to run:", error);
  }
}


const wait = (ms) => {
  const start = Date.now();
  let now = start;
  while (now - start < ms) {
    now = Date.now();
  }
};

async function sendCommandToSSM(params) {
  // Send the command to the EC2 instance
  const command = new SendCommandCommand(params);
  const response = await ssmClient.send(command);

  if (!response?.Command?.CommandId) {
    console.error("❌ Error: Command ID not received");
  } else {
    console.log(
      "✅ Command sent successfully. Command ID:",
      response.Command.CommandId
    );
  }
}

let count = 0;
async function runCommand(params) {
  try {
    // Send the command to the EC2 instance
    await sendCommandToSSM(params);

    // Optionally, you can check the result after the command has completed.
    // You would typically poll the command status here.
  } catch (error) {
    console.error(`⚠️ Failed sending command ${count}, trying again until 40...`);
    if (count < 40) {
      wait(500);
      count += 1;
      await runCommand(params);
    }
  }
}

const getScript = (secret, owner, s3BucketName) => {
  const script = `#!/bin/bash

  cd /home/ec2-user/actions-runner

  unique_value=$(date +%s)
  name="Harrier Runner-$unique_value"

  response=$(curl -L \
    -X POST \
    -H "Accept: application/vnd.github+json" \
    -H "Authorization: Bearer ${secret}" \
    -H "X-GitHub-Api-Version: 2022-11-28" \
    https://api.github.com/orgs/${owner}/actions/runners/generate-jitconfig \
    -d '{"name":"'"$name"'","runner_group_id":1,"labels":["self-hosted"],"work_folder":"_work"}')

  # echo $response

  runner_id=$(echo "$response" | jq '.runner.id')
  runner_name=$(echo "$response" | jq -r '.runner.name')
  encoded_jit_config=$(echo "$response" | jq -r '.encoded_jit_config')

  echo "Runner ID: $runner_id"
  echo "Runner Name: $runner_name"
  #echo "Encoded JIT Config: $encoded_jit_config"

  cd ..
  sudo chown ec2-user:ec2-user ./actions-runner
  cd actions-runner
  sudo chown ec2-user:ec2-user ./s3bucket

  su - ec2-user -c "mount-s3 ${s3BucketName} /home/ec2-user/actions-runner/s3bucket"
  su - ec2-user -c "/home/ec2-user/actions-runner/run.sh --jitconfig $encoded_jit_config"

  echo "Done..."`;

  return script;
}

const main = async (action, secret, owner) => {
  if (action === "queued") {
    console.log("🔍 Calling findS3Bucket from our Lambda");
    const s3BucketName = await findS3Bucket();
    if (!s3BucketName) {
      throw new Error('❌ S3 bucket not found!');
    }
    console.log(`✅ Found S3 Bucket ${s3BucketName}`);
    
    console.log("🔍 Calling findInstance from our Lambda");
    const instanceId = await findInstance("stopped"); // This could return undefined currently, if no stopped instances are found
    if (instanceId) {
      console.log("Calling startInstance from workflow lambda");
      await startInstance(instanceId);

      // Wait for instance to be running?????????
      await waitForInstanceRunning(instanceId);

      // Parameters for the SendCommand API
      const params = {
        DocumentName: "AWS-RunShellScript", // This document allows running shell scripts
        InstanceIds: [instanceId], // Replace with your EC2 instance ID
        Parameters: {
          commands: [getScript(secret, owner, s3BucketName)], // Specify the shell script to run
        },
      };
      await runCommand(params);
      console.log("✅ Shell Script successfully run");
    } else {
      console.log("❌ Error: instanceId missing!");
    }
  } else if (action === "completed") {
    console.log("🔍 Calling findInstance from our Lambda");
    // Does the webhook payload include the name of the runner that has completed the work?
    // Maybe we can send the instanceId as part of the JIT request so that it can be
    //   returned with the completed webhook...
    const instanceId = await findInstance("running"); // This could return undefined currently, if no running instances are found
    if (instanceId) {
      console.log("✅ Calling stopInstance from workflow lambda");
      await stopInstance(instanceId);
    } else {
      console.log("❌ Error: instanceId missing!");
    }
  }
};


export const handler = async (event) => {
  try {
    const action = event.action.trim();
    console.log("🚀 GitHub Workflow Action:", action);

    const owner = event.repository.owner.login.trim();
    console.log("🚀 GitHub Workflow Owner:", owner);

    const secretResponse = await secretClient.send(
      new GetSecretValueCommand({
        SecretId: secretName,
        VersionStage: "AWSCURRENT", // VersionStage defaults to AWSCURRENT if unspecified
      })
    );

    // const secret = secretResponse.SecretString;

    await main(action, secretResponse.SecretString, owner);

    const response = {
      statusCode: 200,
      body: JSON.stringify("Called workflow lambda"),
    };
    return response;
  } catch (error) {
    console.error(`❌ Error getting secret`);
    throw error;
  }
};

// handler(EVENT);

// await main("queued");

// wait(1000 * 60);
// await main("completed");
