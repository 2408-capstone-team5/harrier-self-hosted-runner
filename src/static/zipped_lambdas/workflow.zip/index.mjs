export const handler = async (event) => {
  console.log(event);
  switch (event.action) {
    case 'queued':
      console.log('queued');
      break;
    case 'completed':
      console.log('completed ');
      break
    default:
      console.log('default');
      break;
  }
  return {
    statusCode: 200,
    body: JSON.stringify("Called workflow lambda"),
  }
};

