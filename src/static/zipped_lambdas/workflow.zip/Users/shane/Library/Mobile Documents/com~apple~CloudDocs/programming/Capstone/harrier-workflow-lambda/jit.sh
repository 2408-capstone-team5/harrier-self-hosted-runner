#!/bin/bash

# Execute curl command and capture its output
response=$(curl -L \
  -X POST \
  -H "Accept: application/vnd.github+json" \
  -H "Authorization: Bearer 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" \
  -H "X-GitHub-Api-Version: 2022-11-28" \
  https://api.github.com/orgs/2408-capstone-team5/actions/runners/generate-jitconfig \
  -d '{"name":"New runner","runner_group_id":1,"labels":["self-hosted"],"work_folder":"_work"}')

# Use jq to parse and extract specific fields
runner_id=$(echo "$response" | jq '.runner.id')
runner_name=$(echo "$response" | jq -r '.runner.name')
encoded_jit_config=$(echo "$response" | jq -r '.encoded_jit_config')

echo "Runner ID: $runner_id"
echo "Runner Name: $runner_name"
echo "Encoded JIT Config: $encoded_jit_config"