// import { fromIni } from "@aws-sdk/credential-provider-ini"; // For loading credentials from ~/.aws/credentials
import {
  SSMClient,
  SendCommandCommand,
  SendCommandCommandInput,
} from "@aws-sdk/client-ssm";
import {
  EC2Client,
  DescribeInstancesCommand,
  DescribeInstancesCommandInput,
  DescribeInstancesCommandOutput,
  //   StartInstancesCommand,
} from "@aws-sdk/client-ec2";
import {
  APIGatewayProxyEvent,
  APIGatewayProxyResult,
} from "@aws-sdk/client-lambda";

type InstanceState =
  | "stopped"
  | "running"
  | "pending"
  | "stopping"
  | "shutting-down"
  | "terminated";

const REGION = "us-east-1"; // Change to your desired region

// Initialize the EC2 client
const ssmClient = new SSMClient({
  region: REGION,
  // credentials: fromIni({ profile: "default" }), // Load credentials from the default profile
});

// eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-call
const ec2Client = new EC2Client({
  region: REGION,
  // credentials: fromIni({ profile: "default" }), // Load credentials from the default profile
});

const script = ``;

async function findInstance(state: InstanceState): Promise<string | undefined> {
  try {
    const params: DescribeInstancesCommandInput = {
      MaxResults: 1, // Just get 1 for now
      Filters: [
        { Name: "instance-state-name", Values: [state] },
        {
          Name: "tag:Agent",
          Values: ["Harrier-Runner"], // Looks for a "Harrier-Runner" value for the "Agent" tag
        },
      ],
    };

    const command = new DescribeInstancesCommand(params);
    const data: DescribeInstancesCommandOutput = await ec2Client.send(command);
    let instanceId: string;
    if (data.Reservations?.length) {
      instanceId = data.Reservations[0];
      console.log("Found instance:", instanceId);
      return instanceId;
    } else {
      return undefined;
    }
  } catch (error: unknown) {
    if (error instanceof Error) {
      console.error("Error finding instance:", error.message);
    } else {
      console.error("Unexpected error:", error);
    }
    return undefined;
  }
}

async function startInstance(instanceId: string) {
  try {
    console.log(`Trying to start instanceId: ${instanceId}`);
    const params = {
      InstanceIds: [instanceId],
    };
    const command = new StartInstancesCommand(params);
    const response = await client.send(command);
    console.log("Instance start command sent:", response.StartingInstances);
  } catch (error) {
    console.error("Error starting instances:", error);
  }
}

async function runCommand(params: SendCommandCommandInput) {
  try {
    // Send the command to the EC2 instance
    const command = new SendCommandCommand(params);
    const response = await ssmClient.send(command);

    if (!response?.Command?.CommandId) {
      console.error("Error: Command ID not received");
    } else {
      console.log(
        "Command sent successfully. Command ID:",
        response.Command.CommandId
      );
    }

    // Optionally, you can check the result after the command has completed.
    // You would typically poll the command status here.
  } catch (error) {
    console.error("Error sending command:", error);
  }
}

const main = async (action: string): Promise<void> => {
  //   const action = "queued"; // Would come in on event from API in prod

  if (action === "queued") {
    console.log("Calling findInstance from our Lambda");
    const instanceId = await findInstance("stopped"); // This could return undefined currently, if no stopped instances are found
    if (instanceId) {
      console.log("Calling startInstance from workflow lambda");
      await startInstance(instanceId);

      // Wait for instance to be running?????????
      // Parameters for the SendCommand API
      const params: SendCommandCommandInput = {
        DocumentName: "AWS-RunShellScript", // This document allows running shell scripts
        InstanceIds: [instanceId], // Replace with your EC2 instance ID
        Parameters: {
          commands: [script], // Specify the shell script to run
        },
      };

      void runCommand(params);
    } else {
      console.log("instanceId missing!");
    }
  }
};

// void main();

export const handler = async (
  event: APIGatewayProxyEvent
): Promise<APIGatewayProxyResult> => {
  const action: string = event.action.trim();
  console.log("GitHub Workflow Action:", action);
  await main(action);

  const response = {
    statusCode: 200,
    body: JSON.stringify("Called workflow lambda"),
  };
  return response;
};
// function fromIni(arg0: {
//   profile: string;
// }):
//   | import("@smithy/types").AwsCredentialIdentity
//   | import("@smithy/types").AwsCredentialIdentityProvider
//   | undefined {
//   throw new Error("Function not implemented.");
// }
